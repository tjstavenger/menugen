//$Id: Cellular.java 14736 2008-06-04 14:23:42Z hardy.ferentschik $
package org.hibernate.test.annotations.entitynonentity;

/**
 * @author Emmanuel Bernard
 */
public class Cellular extends Phone {
	String brand;
}
