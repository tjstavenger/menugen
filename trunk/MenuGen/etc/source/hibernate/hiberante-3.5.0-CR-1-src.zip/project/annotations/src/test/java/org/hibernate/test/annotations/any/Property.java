package org.hibernate.test.annotations.any;

public interface Property {

	public String getName();
	public String asString();
}
