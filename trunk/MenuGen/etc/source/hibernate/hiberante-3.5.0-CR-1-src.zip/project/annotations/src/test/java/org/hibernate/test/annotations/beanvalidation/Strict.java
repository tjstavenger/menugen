package org.hibernate.test.annotations.beanvalidation;

/**
 * @author Emmanuel Bernard
 */
public interface Strict {
}
