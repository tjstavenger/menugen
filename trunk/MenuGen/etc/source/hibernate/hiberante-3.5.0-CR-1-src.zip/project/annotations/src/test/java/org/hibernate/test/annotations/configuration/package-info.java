@GenericGenerator(name = "myGenerator", strategy = "sequence")
package org.hibernate.test.annotations.configuration;

import org.hibernate.annotations.GenericGenerator;
